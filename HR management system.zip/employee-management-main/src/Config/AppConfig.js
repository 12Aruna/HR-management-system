const appConfig = {
  appVersion: "v20.03.24.04",
};
export default appConfig;
